[haxe]: http://http://haxe.org
[nodejs]:http://nodejs.org/
[haxelib]:http://lib.haxe.org

# Std [haxe lib][haxelib] for [node.js][nodejs]

### Description

This library contains all you need to use haxe plus the std libary with node.js.

Starting with the git tag v0.10.25 and the branch node_pre0.10.25, when there are breaking API changes in Node.js then a new branch will be created here.  The master branch will match follow the most current version of Node.js.

### Coming soon:

Examples and getting started!

### History

This library was forked from [Ritchie Turner's nodejs library](https://github.com/cloudshift) ([legacy haxelib site](http://lib.haxe.org/legacy/p/nodejs)) due to lack of maintenance.





